# Color Resonance 習得技 第5セット

翠蔦の輪舞・七色の結界・パレット・レゾナンスの3点です。ファイルは `assets/generated/` にあります。

## 使い方



| 素材ID | 習得技ID | 方向 | 単発GIF | 総尺 / GIF可視終端 / PNG再生定義の可視終端 |
|---|---|---|---|---|
| vine_round_dance | ivy_dance | 正面・時計回り | [effect.gif](gifs/vine_round_dance/effect.gif) | 2540ms / 1820ms / 1820ms |
| seven_color_barrier | king_canvas | 正面 | [effect.gif](gifs/seven_color_barrier/effect.gif) | 2540ms / 1820ms / 1820ms |
| palette_resonance | king_resonance | 右 | [effect.gif](gifs/palette_resonance/effect.gif) | 2540ms / 1720ms / 1820ms |

各288×384・12PNGセル・4列×3行シート・14コマの単発GIFです。`preview.gif` だけ反復します。開始透明100msを除いたGIF不透明表示は、葉環と結界1720ms、斬撃1620msです。透明尾部は葉環と結界720ms、斬撃820ms。PNG自体は保持時間を持たず、PNGの終端はmanifestの再生定義です。GIFは1bit透過の輪郭縮退、PNGは縮退とアルファ減衰で、同じ半透明フェードではありません。

翠蔦の輪舞は3枚の葉と閉じた蔦の環を、中心(144,205)で時計回りに0→30→60→90度回転させ、その後全体を縮退します。生成原本の完全なセル0〜3を採用し、保持・解除は同じ完全なセル3から組み立てています。元の大きなセル4〜7は採用せず、編集元として残しています。`adoptedSourceCells` / `unusedSourceCells` / `phaseTransforms` に選択と撮影変換を保存しています。

七色の結界は左の暖色と右の寒色、白い縁を持つ中空の結界です。中央は透明なので味方に重ねられます。パレット・レゾナンスは一体になった七色の斬撃で、効果レイヤーだけ左右反転できます。この2技は底点(144,307)を変換の基準にします。基準点が固定でも、ラスタ化や透過閾値で輪郭画素に数画素の差が出ます。登録と輪郭bboxはmetadataを参照してください。斬撃GIFは原画のアルファを全ピクセル保持し、専用原本の処理では輪郭周辺8pxの色だけを生成した色付き縁から採用して書き出しています。帯外不変は原本処理の話であり、GIF全体は共通パレットで再量子化するため、内側のRGB値も旧GIFと同一ではありません。PNGの主原本・全セルは同じまま、白い外縁のGIF劣化を抑えています。明るい背景では濃い青紫の線や階段状の縁が残るため、完全に柔らかい発光を再現するものではありません。編集ドナー、採用マスク、専用原本、`gifSourceEdit` と生成プロンプトを保存しています。

実コピーの `GameArt.sample` で3技の全コマ開始・切替直前1ms・単発終了の84アサートが通過しています。回転・縮退後を含む全PNGセルの透明外枠24px/32px、全GIFコマ、共通パレット、単発終端を検証しています。連続視覚再生と実ゲーム内配置は未実施、ゲーム本体への自動組み込みは行っていません。

```sh
python3 tools/build_learned_assets.py --records assets/generated/learned-set-05.json
```

採用原本、葉環と結界の編集前シート、実参照セル、生成・修正プロンプト、固定登録座標、回転・縮退設定を保持しています。葉環の不採用セルをそのまま使わず、完成済みPNGシートとmanifestのコマ順を使ってください。


## Canvasの共通例

```js
// 再生開始時刻を技の発動時に一度だけ記録する。
const startMs = performance.now();
const elapsedMs = performance.now() - startMs;
if (elapsedMs < animation.durationMs) {
  let time = Math.max(0, elapsedMs), index = 0;
  while (index < animation.durationsMs.length - 1 && time >= animation.durationsMs[index]) {
    time -= animation.durationsMs[index++];
  }
  const cel = animation.sequence[index];
  if (cel !== null) {
    const sx = cel % asset.grid.columns * 288;
    const sy = Math.floor(cel / asset.grid.columns) * 384;
    ctx.drawImage(sheet, sx, sy, 288, 384, x - 144, y - 192, 288, 384);
  }
}
```
