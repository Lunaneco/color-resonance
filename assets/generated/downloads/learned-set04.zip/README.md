# Color Resonance 習得技 第4セット

蒼海の一太刀・暁の砕光の2点です。ファイルは `assets/generated/` にあります。

## 使い方



| 素材ID | 習得技ID | 方向 | 単発GIF | 総尺 / GIF可視終端 / PNG再生定義の可視終端 |
|---|---|---|---|---|
| azure_tide_strike | gran_tide | 右 | [effect.gif](gifs/azure_tide_strike/effect.gif) | 2540ms / 1720ms / 1820ms |
| dawn_shatter | spinel_sun | 正面 | [effect.gif](gifs/dawn_shatter/effect.gif) | 2540ms / 1720ms / 1820ms |

各288×384・12PNGセル・4列×3行シート・14コマの単発GIFです。専用 `preview.gif` だけ反復します。GIFは開始透明100ms、実不透明表示1620ms、透明尾部820ms。PNG単体に保持時間はなく、PNGの終端はmanifestのコマ順と保持時間で定義しています。PNGは縮退とアルファ減衰、GIFは輪郭の縮退を使います。GIFの透過は1bitのため、残る不透明画素は常に255/255で、PNGと同じ半透明フェードではありません。最終PNGの微弱な残光はGIF透過閾値96未満になり、最後の100msセルもGIFでは透明です。`visibleEndMs` / `phases` は復号GIF、`pngVisibleEndMs` / `pngPhases` はPNG再生定義に一致しています。

蒼海の一太刀は一本の白い切刃を持つ大波を、選択地点の範囲へ重ねる効果です。既存素材ID `gran_tide` と区別し、新しい素材IDを `azure_tide_strike` としました。右向きの効果だけ反転できます。暁の砕光は白い芯と左右の光を持つ、正面からの黄金光です。主要8セルの輪郭bbox下端は、アルファ96/255以上・exclusiveの範囲終端座標で307〜309px（実画素306〜308px）です。どちらも基準点(144,307)を固定した変換で全体を縮退させ、波の一部や左右光だけを途中で消していません。輪郭の全画素が完全静止する意味ではなく、ラスタ化と透過閾値により数画素の差があり、金の終盤では下端が最大2〜4px上がる場合があります。

実コピーの `GameArt.sample` で2技の全コマ開始・切替直前1ms・単発終了の56アサートが通過しています。PNG/GIFの全コマ、透明外枠、単発終端、共通パレットを検証しています。連続視覚再生と実ゲーム内配置は未実施、ゲーム本体への自動組み込みは行っていません。

```sh
python3 tools/build_learned_assets.py --records assets/generated/learned-set-04.json
```

大波の越境した初稿は `source/azure_tide_strike-base.png` に保持しています。長い裾を画像生成で短い完全な輪郭を持つ波へ描き直した主原本、金の原本、実参照セル、生成・修正プロンプト、登録座標、`phaseTransforms` を保存しています。第1セットのCanvas共通例と対応表で一度だけ再生できます。

## Canvasの共通例

```js
// 再生開始時刻を技の発動時に一度だけ記録する。
const startMs = performance.now();
const elapsedMs = performance.now() - startMs;
if (elapsedMs < animation.durationMs) {
  let time = Math.max(0, elapsedMs), index = 0;
  while (index < animation.durationsMs.length - 1 && time >= animation.durationsMs[index]) {
    time -= animation.durationsMs[index++];
  }
  const cel = animation.sequence[index];
  if (cel !== null) {
    const sx = cel % asset.grid.columns * 288;
    const sy = Math.floor(cel / asset.grid.columns) * 384;
    ctx.drawImage(sheet, sx, sy, 288, 384, x - 144, y - 192, 288, 384);
  }
}
```
