## 敵の出現 第11セット



| 素材ID | 対象 | 単発GIF |
|---|---|---|
| kegare_reinforcement | 通常章の核が生む新しい敵 | [effect.gif](gifs/kegare_reinforcement/effect.gif) |
| membrane_emergence | 終章の第二段で可視になる膜の敵 | [effect.gif](gifs/membrane_emergence/effect.gif) |

実コピー `board.js` の核による3ターンごとの増援生成と、`enterPhase1` で隠れた膜の敵を可視にする処理に合わせました。核の増援は生成が成功して `units.push(u)` した時、かつ `!cfg.inverted` の場合だけ使います。白い膜は `cfg.inverted && u.kind==='membrane'` の隠れた敵を解除し、`bornT` を更新した時だけです。**クロム本体には使いません。** 新しい敵や能力を作る素材ではなく、既存の600ms出現フェードの左右に添える大きな立ち上がり跡です。身体・顔・目・武器・文字はありません。第9の消去、第10の着弾とは用途が異なります。ゲーム本体には未接続です。

各256×192・12PNGセル・4列×3行1024×576シートです。開始透明40ms、セル000〜007各80ms、008〜011各100ms、終了透明520msの14コマGIFで総尺1600ms。PNG/GIFの可視終端は1080msです。保存用 `effect.gif` は一度だけ透明で終了し、一覧用 `preview.gif` だけ反復します。セル005/006は同じピーク形状を440〜600msの160ms保持します。12セル全てが別形状ではありません。

足元pivot(128,128)、基準タイル幅80、左右の根元(82,128)/(174,128)を固定します。原画の2本を、根元から高さ0.10→0.25→0.45→0.65→0.85→1倍・幅0.70→0.75→0.80→0.85→0.90→1倍に立ち上げます。600msの出生フェードが終わった時点から、0.90→0.70→0.45→0.22→0.06倍へ等方収縮します。全12セルのalpha閾値96以上の各輪郭bbox下端は128です（最後の不透明行はy127）。PNGの弱いAAまで全てがこの線で終わるという意味ではありません。

全PNG/GIFの中央矩形(112,24)-(144,168)はalpha0、外枠24pxも完全透明です。原画から描いた側方表現で、実敵の身体を精密に囲う形ではありません。床の後・敵の前のレイヤーへ描き、出生時のセルの足元へ合わせる使い方を想定しています。新しい敵の隣にいる別のユニットとの重なりと実視認性は未確認です。

PNGの最後4セルはalpha0.9→0.8→0.7→0.6も使います。GIFは原画の色を保って輪郭を縮小し、RGB暗化しません。共通255色＋透過色、閾値96、ディザなし、disposal=2です。GIFの終盤5セルの面積は灰紫3079→1847→776→188→12、白1817→1098→453→110→9画素。白の終盤平均RGBは226.15〜230.57を保ちます。元の主要形状は2本、追加粒子システムはありませんが、ラスタ化による小さい分離画素が残る場合があり、粒ゼロや全画素完全不透明とはしません。灰紫原画の最大alphaは254です。タイル幅64pxでピークを静止比較し、開始・末尾は小さな跡になります。明るい床での白のコントラストは弱めです。

```js
function drawEnemyEmergence(ctx, asset, sheet, elapsedMs, footX, footY, tw) {
  const cel = GameArt.sample(asset.id, 'effect', elapsedMs);
  if (!sheet || cel == null) return;
  const [w, h] = asset.grid.cellSize, scale = tw / 80;
  ctx.drawImage(sheet, (cel % 4) * w, Math.floor(cel / 4) * h, w, h,
    footX - 128 * scale, footY - 128 * scale, w * scale, h * scale);
}
// 増援生成/膜のhidden解除時に出生セルとbornTを保持する。
// GameArt.load([id])で読み込み、床の後・ユニットの前に描き1600msで終了。
// GameArt.drawのbboxフィットではなく、同じ足元・倍率で全コマ描く。
```

実shade/membrane参照、生成原画・修正前原画、両プロンプト、切り出し・根元・尺度・時間は `emergence-set-11.json` / `prompts.json` とZIPに保存しています。`review/kegare_reinforcement.jpg` / `review/membrane_emergence.jpg` の地面線は確認画像だけにあります。実コピー `GameArt.sample` の開始・中点・直前・終端について90アサートが通過しています。**連続視覚再生・実ゲーム内配置は未確認**です。

```sh
python3 tools/build_emergence_assets.py
```
