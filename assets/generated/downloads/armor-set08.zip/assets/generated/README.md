## 鉛装甲 第8セット



| 素材ID | 発生条件 | 単発GIF | 接触時刻（可視開始から） |
|---|---|---|---|
| lead_layer_peel | 鉛の層が減り、まだ残る | [effect.gif](gifs/lead_layer_peel/effect.gif) | 1枚：360ms |
| lead_shell_break | 鉛の層が1以上から0になる | [effect.gif](gifs/lead_shell_break/effect.gif) | 左434ms・右405ms・上548ms |

実コピー `board.js` の鉛装甲更新に対応する、受け側のイベント素材です。前の装甲値と更新後の装甲値を比較し、減った瞬間に一度だけ再生します。通常攻撃は1層、スピネルの貫通攻撃などは残る層をまとめて剥がします。正稿の「殻のように割れて落ちた」「体には触れない」に合わせ、対象の本体・顔・刃を描かず、外殻の1枚または3枚だけを外へ剥がして落とします。ゲーム本体には未接続です。

各256×192・12PNGセル・4列×3行の1024×576シートです。GIFは開始の透明80ms、セル000〜008各80ms、009〜011各120ms、終了の透明640msの14コマ、総尺1800msです。可視終端はPNG/GIFとも1160ms。保存用 `effect.gif` はループせず、一覧用 `preview.gif` だけが繰り返します。対応表の `sequence` は `[null,0,1,2,3,4,5,6,7,8,9,10,11,null]`、`loop:false` です。

固定の足元pivot(128,128)・地面y128・基準タイル幅80です。各板は飛行中に同じ大きさを保持し、外向きの水平速度と重力420px/s²で落下します。回転した不透明輪郭の最初の地面接触を1ms刻みで求め、その位置と姿勢で止めます。全板が着地した後、セル009〜011だけ接地点へ0.65→0.35→0.12倍に縮小し、最後の小さな残片を消します。着地前には縮めません。接地点は剥離x98、殻割れx87・202.5・136、丸め誤差は0.5px以内です。地面線付きの各12コマ比較を `review/lead_layer_peel.jpg` / `review/lead_shell_break.jpg` に保存しています。地面線は確認画像だけにあり、GIF/PNG素材には含みません。

PNGは消失3セルのalphaを0.85→0.65→0.45とし、滑らかな半透明を保持します。GIFには半透明がないため、同じ縮小とRGB暗化0.85→0.65→0.45・二値透過を使います。**GIFの末段階は縮小と暗化による消失表現で、滑らかな半透明フェードではありません。** 最終残片の幅はGIFで各6px以下、PNGはごく薄いAA縁を含め各最大7pxです。最終GIFの下端y126には、PNGの不透明輪郭より1px上になる量子化差を許容しています。背景に自然に透ける消失はPNGシートを使います。共通255色＋透過色、閾値96、ディザなし、disposal=2です。不透明輪郭（alpha96以上）は地面下へ侵入せず、PNGのごく薄いAA縁は地面の下に最大alpha3で残る場合があります。外枠24pxは完全透明です。

```js
// assetはmanifestの該当エントリー。sheetはGameArt.load([asset.id])で読んだPNG。
function drawArmorFragments(ctx, asset, sheet, elapsedMs, footX, footY, tw) {
  const cel = GameArt.sample(asset.id, 'effect', elapsedMs);
  if (!sheet || cel == null) return;
  const [w, h] = asset.grid.cellSize;
  const scale = tw / 80;
  ctx.drawImage(sheet, (cel % 4) * w, Math.floor(cel / 4) * h, w, h,
    footX - 128 * scale, footY - 128 * scale, w * scale, h * scale);
}
// armorが減った瞬間のunitXY(d)を足元として保持し、経過時刻を渡す。
// 更新後armor>0ならlead_layer_peel、armor===0ならlead_shell_breakを選ぶ。
// 1800ms後はイベントを終了。GameArt.drawのbbox中心/下端へのフィットは使わない。
```

原画・実ゲーム参照・プロンプト・切り出し範囲・速度・回転・接触時刻・全セルの座標は `armor-set-08.json` / `prompts.json` に保持しています。復号GIFで終端・透過・段階的な縮小と暗化を確認し、実コピー `GameArt.sample` の90アサートが通過しています。**連続視覚再生・実ゲーム内配置は未確認**です。

```sh
python3 tools/build_armor_assets.py
```
